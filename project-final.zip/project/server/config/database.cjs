const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    // Use local MongoDB connection
    const mongoURI = 'mongodb://localhost:27017/interviewai';
    
    console.log('Attempting to connect to MongoDB...');
    console.log('MongoDB URI:', mongoURI);
    
    const conn = await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000, // Timeout after 5s instead of 30s
      socketTimeoutMS: 45000, // Close sockets after 45s of inactivity
    });

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
    console.log(`📊 Database: ${conn.connection.name}`);
    
    // Handle connection events
    mongoose.connection.on('error', (err) => {
      console.error('❌ MongoDB connection error:', err);
    });

    mongoose.connection.on('disconnected', () => {
      console.log('⚠️ MongoDB disconnected');
    });

    mongoose.connection.on('reconnected', () => {
      console.log('✅ MongoDB reconnected');
    });

    process.on('SIGINT', async () => {
      await mongoose.connection.close();
      console.log('🔄 MongoDB connection closed through app termination');
      process.exit(0);
    });

  } catch (error) {
    console.error('❌ Error connecting to MongoDB:', error.message);
    console.log('💡 Make sure MongoDB is running locally on port 27017');
    console.log('💡 You can start MongoDB with: mongod --dbpath /data/db');
    
    // Don't exit in development, allow app to run without DB for testing
    if (process.env.NODE_ENV === 'production') {
      process.exit(1);
    } else {
      console.log('⚠️ Running in development mode without database connection');
    }
  }
};

module.exports = connectDB;