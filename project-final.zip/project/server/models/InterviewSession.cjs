const mongoose = require('mongoose');

const responseSchema = new mongoose.Schema({
  questionId: {
    type: String,
    required: true
  },
  answer: {
    type: String,
    required: true
  },
  timeSpent: {
    type: Number,
    required: true
  },
  confidence: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  timestamp: {
    type: Date,
    default: Date.now
  }
});

const questionSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true
  },
  text: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['text', 'coding', 'behavioral', 'analytical'],
    required: true
  },
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard'],
    required: true
  },
  timeLimit: {
    type: Number,
    required: true
  },
  expectedKeywords: [String]
});

const feedbackSchema = new mongoose.Schema({
  overall: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  communication: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  technicalAccuracy: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  problemSolving: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  confidence: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  strengths: [String],
  weaknesses: [String],
  suggestions: [String]
});

const interviewSessionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    enum: ['aptitude', 'group-discussion', 'hr', 'technical'],
    required: true
  },
  domain: {
    type: String,
    enum: [
      'software-engineering',
      'data-science',
      'product-management',
      'marketing',
      'finance',
      'sales',
      'operations',
      'design'
    ],
    required: true
  },
  jobRole: String,
  companyName: String,
  questions: [questionSchema],
  responses: [responseSchema],
  feedback: feedbackSchema,
  startTime: {
    type: Date,
    required: true
  },
  endTime: Date,
  status: {
    type: String,
    enum: ['in-progress', 'completed', 'abandoned'],
    default: 'in-progress'
  },
  duration: {
    type: Number,
    required: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('InterviewSession', interviewSessionSchema);