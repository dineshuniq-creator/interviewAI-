const express = require('express');
const InterviewSession = require('../models/InterviewSession.cjs');
const { authenticateToken } = require('../middleware/auth.cjs');

const router = express.Router();

// Get user's interview sessions
router.get('/sessions', authenticateToken, async (req, res) => {
  try {
    const sessions = await InterviewSession.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .limit(50);

    res.json({
      success: true,
      sessions
    });
  } catch (error) {
    console.error('Error fetching sessions:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch interview sessions'
    });
  }
});

// Get specific session
router.get('/sessions/:id', authenticateToken, async (req, res) => {
  try {
    const session = await InterviewSession.findOne({
      _id: req.params.id,
      userId: req.user._id
    });

    if (!session) {
      return res.status(404).json({
        success: false,
        message: 'Session not found'
      });
    }

    res.json({
      success: true,
      session
    });
  } catch (error) {
    console.error('Error fetching session:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch session'
    });
  }
});

// Create new interview session
router.post('/sessions', authenticateToken, async (req, res) => {
  try {
    const sessionData = {
      ...req.body,
      userId: req.user._id
    };
    
    const session = new InterviewSession(sessionData);
    await session.save();
    
    res.status(201).json({
      success: true,
      session
    });
  } catch (error) {
    console.error('Error creating session:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create interview session'
    });
  }
});

// Update session (for completing interview)
router.put('/sessions/:id', authenticateToken, async (req, res) => {
  try {
    const session = await InterviewSession.findOneAndUpdate(
      { _id: req.params.id, userId: req.user._id },
      req.body,
      { new: true }
    );

    if (!session) {
      return res.status(404).json({
        success: false,
        message: 'Session not found'
      });
    }

    res.json({
      success: true,
      session
    });
  } catch (error) {
    console.error('Error updating session:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update session'
    });
  }
});

// Generate feedback (can be expanded with AI integration)
router.post('/feedback', authenticateToken, async (req, res) => {
  try {
    const { responses, questions, type } = req.body;
    
    // Basic feedback generation - can be enhanced with AI
    const avgConfidence = responses.reduce((sum, r) => sum + r.confidence, 0) / responses.length;
    const avgResponseLength = responses.reduce((sum, r) => sum + r.answer.length, 0) / responses.length;
    
    const communication = Math.min(100, Math.max(50, avgResponseLength / 10 + Math.random() * 20));
    const technicalAccuracy = Math.min(100, Math.max(40, avgConfidence * 0.8 + Math.random() * 30));
    const problemSolving = Math.min(100, Math.max(45, avgConfidence * 0.9 + Math.random() * 25));
    const confidence = avgConfidence;
    const overall = Math.round((communication + technicalAccuracy + problemSolving + confidence) / 4);

    const feedback = {
      overall,
      communication: Math.round(communication),
      technicalAccuracy: Math.round(technicalAccuracy),
      problemSolving: Math.round(problemSolving),
      confidence: Math.round(confidence),
      strengths: ['Clear communication', 'Good technical understanding'],
      weaknesses: ['Could provide more detailed examples'],
      suggestions: ['Practice explaining concepts with real-world examples', 'Work on structuring responses better']
    };
    
    res.json({
      success: true,
      feedback
    });
  } catch (error) {
    console.error('Error generating feedback:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate feedback'
    });
  }
});

module.exports = router;