import React from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  CheckCircle,
  XCircle,
  TrendingUp,
  TrendingDown,
  BarChart3,
  Clock,
  Target,
  ArrowRight,
} from 'lucide-react';
import { useUser } from '../contexts/UserContext';
import { getScoreColor, getScoreBadgeColor, getDomainDisplayName } from '../utils/helpers';

export function ResultsPage() {
  const { sessionId } = useParams();
  const { sessions } = useUser();

  // Try to find session by ID (MongoDB _id or local id)
  const session = sessionId
    ? sessions.find((s) =>s._id === sessionId)
    : null;

  // --- Handle skipped/no session or no answers ---
  const answeredCount = session?.responses
    ? session.responses.filter((r) => r.answer && r.answer.trim()).length
    : 0;

  if (!session || answeredCount === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <XCircle className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">No Answers Provided</h1>
          <p className="text-gray-600 mb-6">
            You skipped all questions. Please answer at least one question to
            generate feedback and save your interview session.
          </p>
          <Link
            to="/setup"
            className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Take Interview Again
          </Link>
        </div>
      </div>
    );
  }

  const { feedback } = session;

  if (!feedback) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Generating your feedback...</p>
        </div>
      </div>
    );
  }

  // --- Calculate average confidence safely ---
  const avgConfidence =
    answeredCount > 0
      ? Math.round(
          session.responses
            .filter((r) => r.answer && r.answer.trim())
            .reduce((sum, r) => sum + (r.confidence || 0), 0) / answeredCount
        )
      : 0;

  const getGradeFromScore = (score) => {
    if (score >= 90) return 'A+';
    if (score >= 80) return 'A';
    if (score >= 70) return 'B+';
    if (score >= 60) return 'B';
    if (score >= 50) return 'C';
    return 'D';
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 text-green-600 rounded-full mb-4">
            <CheckCircle className="h-8 w-8" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Interview Complete!</h1>
          <p className="text-lg text-gray-600">
            {session.type
              .split('-')
              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
              .join(' ')}{' '}
            • {getDomainDisplayName(session.domain)}
          </p>
        </div>

        {/* Overall Score */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-6 text-center">
          <div className="mb-6">
            <div className={`text-6xl font-bold ${getScoreColor(feedback.overall)} mb-2`}>
              {feedback.overall}%
            </div>
            <div
              className={`inline-block px-4 py-2 rounded-full text-lg font-semibold ${getScoreBadgeColor(
                feedback.overall
              )}`}
            >
              Grade: {getGradeFromScore(feedback.overall)}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <div className="text-2xl font-bold text-blue-600">{feedback.communication}%</div>
              <div className="text-sm text-gray-600">Communication</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">{feedback.technicalAccuracy}%</div>
              <div className="text-sm text-gray-600">Technical Accuracy</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">{feedback.problemSolving}%</div>
              <div className="text-sm text-gray-600">Problem Solving</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-yellow-600">{feedback.confidence}%</div>
              <div className="text-sm text-gray-600">Confidence</div>
            </div>
          </div>
        </div>

        {/* Session Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <Clock className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <div className="text-2xl font-bold text-gray-900">{session.duration}m</div>
                <div className="text-sm text-gray-600">Duration</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <Target className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <div className="text-2xl font-bold text-gray-900">{answeredCount}</div>
                <div className="text-sm text-gray-600">Questions Answered</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <BarChart3 className="h-8 w-8 text-purple-600 mr-3" />
              <div>
                <div className="text-2xl font-bold text-gray-900">{avgConfidence}%</div>
                <div className="text-sm text-gray-600">Avg Confidence</div>
              </div>
            </div>
          </div>
        </div>

        {/* Feedback Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Strengths */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center mb-4">
              <TrendingUp className="h-6 w-6 text-green-600 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">Strengths</h3>
            </div>
            <ul className="space-y-3">
              {feedback.strengths.map((strength, index) => (
                <li key={index} className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{strength}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Areas for Improvement */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center mb-4">
              <TrendingDown className="h-6 w-6 text-yellow-600 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">Areas for Improvement</h3>
            </div>
            <ul className="space-y-3">
              {feedback.weaknesses.map((weakness, index) => (
                <li key={index} className="flex items-start">
                  <XCircle className="h-5 w-5 text-yellow-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{weakness}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Suggestions */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Personalized Suggestions</h3>
          <div className="space-y-4">
            {feedback.suggestions.map((suggestion, index) => (
              <div key={index} className="flex items-start bg-blue-50 p-4 rounded-lg">
                <div className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                  {index + 1}
                </div>
                <span className="text-gray-700">{suggestion}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/setup"
            className="inline-flex items-center justify-center px-8 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all duration-300"
          >
            Take Another Interview
            <ArrowRight className="h-5 w-5 ml-2" />
          </Link>

          <Link
            to="/dashboard"
            className="inline-flex items-center justify-center px-8 py-3 bg-white text-gray-700 font-semibold rounded-lg border-2 border-gray-300 hover:border-blue-300 hover:text-blue-600 transition-all duration-300"
          >
            <BarChart3 className="h-5 w-5 mr-2" />
            View Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
