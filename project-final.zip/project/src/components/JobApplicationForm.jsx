import React, { useState } from 'react';
import { Upload, FileText, Building, User, Clock, Target } from 'lucide-react';
import { getDomainDisplayName } from '../utils/helpers';

export function JobApplicationForm({ onSubmit, onBack }) {
  const [formData, setFormData] = useState({
    jobRole: '',
    jobDescription: '',
    companyName: '',
    level: 'fresher',
    duration: 30,
    resumeText: '',
    interviewType: 'hr',
    domain: 'software-engineering'
  });

  const [resumeFile, setResumeFile] = useState(null);

  const interviewTypes = [
    { value: 'hr', label: 'HR Round', icon: User, color: 'bg-blue-500' },
    { value: 'technical', label: 'Technical Round', icon: Target, color: 'bg-red-500' },
    { value: 'group-discussion', label: 'Group Discussion', icon: User, color: 'bg-green-500' },
    { value: 'aptitude', label: 'Aptitude Test', icon: Target, color: 'bg-purple-500' }
  ];

  const domains = [
    'software-engineering',
    'data-science',
    'product-management',
    'marketing',
    'finance',
    'sales',
    'operations',
    'design'
  ];

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setResumeFile(file);
      // Simulate resume text extraction
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result;
        setFormData(prev => ({ 
          ...prev, 
          resumeText: text || `Resume content from ${file.name}` 
        }));
      };
      reader.readAsText(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Job Application Details</h2>
          <p className="text-gray-600">Provide details about the position to get personalized interview questions</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Job Role */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Job Role / Position *
            </label>
            <input
              type="text"
              required
              value={formData.jobRole}
              onChange={(e) => setFormData(prev => ({ ...prev, jobRole: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="e.g., Senior Software Engineer, Data Scientist, Product Manager"
            />
          </div>

          {/* Company Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Company Name *
            </label>
            <div className="relative">
              <Building className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <input
                type="text"
                required
                value={formData.companyName}
                onChange={(e) => setFormData(prev => ({ ...prev, companyName: e.target.value }))}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., Google, Microsoft, Startup Inc."
              />
            </div>
          </div>

          {/* Job Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Job Description *
            </label>
            <textarea
              required
              value={formData.jobDescription}
              onChange={(e) => setFormData(prev => ({ ...prev, jobDescription: e.target.value }))}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              placeholder="Paste the job description or key requirements..."
            />
          </div>

          {/* Experience Level */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Experience Level *
            </label>
            <select
              required
              value={formData.level}
              onChange={(e) => setFormData(prev => ({ ...prev, level: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="fresher">Fresher (0-1 years)</option>
              <option value="junior">Junior (1-3 years)</option>
              <option value="mid">Mid-level (3-7 years)</option>
              <option value="senior">Senior (7+ years)</option>
            </select>
          </div>

          {/* Domain */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Domain *
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {domains.map(domain => (
                <button
                  key={domain}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, domain }))}
                  className={`p-3 text-left rounded-lg border-2 transition-all duration-200 ${
                    formData.domain === domain
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 bg-white text-gray-700 hover:border-blue-300 hover:bg-blue-50'
                  }`}
                >
                  <div className="font-medium text-sm">
                    {getDomainDisplayName(domain)}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Interview Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Interview Type *
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {interviewTypes.map((type) => (
                <button
                  key={type.value}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, interviewType: type.value }))}
                  className={`p-4 rounded-lg border-2 transition-all duration-300 text-center ${
                    formData.interviewType === type.value
                      ? 'border-blue-500 bg-blue-50 shadow-md'
                      : 'border-gray-200 bg-white hover:border-blue-300 hover:shadow-md'
                  }`}
                >
                  <div className={`inline-flex items-center justify-center w-8 h-8 ${type.color} text-white rounded-lg mb-2`}>
                    <type.icon className="h-4 w-4" />
                  </div>
                  <div className="font-medium text-sm">{type.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Duration */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Interview Duration: {formData.duration} minutes
            </label>
            <div className="flex items-center space-x-4">
              <Clock className="h-5 w-5 text-gray-400" />
              <input
                type="range"
                min="15"
                max="60"
                step="5"
                value={formData.duration}
                onChange={(e) => setFormData(prev => ({ ...prev, duration: Number(e.target.value) }))}
                className="flex-1"
              />
            </div>
            <div className="flex justify-between text-sm text-gray-500 mt-1">
              <span>15 min</span>
              <span>60 min</span>
            </div>
          </div>

          {/* Resume Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Upload Resume (Optional)
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
              <input
                type="file"
                accept=".pdf,.doc,.docx,.txt"
                onChange={handleFileUpload}
                className="hidden"
                id="resume-upload"
              />
              <label htmlFor="resume-upload" className="cursor-pointer">
                <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600">
                  {resumeFile ? (
                    <span className="text-blue-600 font-medium">{resumeFile.name}</span>
                  ) : (
                    <>Click to upload or drag and drop<br />PDF, DOC, DOCX, TXT</>
                  )}
                </p>
              </label>
            </div>
          </div>

          {/* Resume Text Area (if no file uploaded) */}
          {!resumeFile && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Or paste your resume content
              </label>
              <textarea
                value={formData.resumeText}
                onChange={(e) => setFormData(prev => ({ ...prev, resumeText: e.target.value }))}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                placeholder="Paste your resume content here for more personalized questions..."
              />
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-4 pt-6">
            <button
              type="button"
              onClick={onBack}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Back
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all duration-300 font-medium"
            >
              Start Interview
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}