import React, { useRef, useEffect, useState } from 'react';
import { Camera, CameraOff, Mic, MicOff, Eye, Smile, AlertTriangle } from 'lucide-react';

export function VideoAnalysis({ isActive, onAnalysisUpdate }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [stream, setStream] = useState(null);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [analysis, setAnalysis] = useState({
    eyeContact: 0,
    smileFrequency: 0,
    headMovement: 0,
    confidence: 0,
    engagement: 0
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (isActive) {
      startVideo();
    } else {
      stopVideo();
    }

    return () => {
      stopVideo();
    };
    // eslint-disable-next-line
  }, [isActive]);

  useEffect(() => {
    let analysisInterval;
    if (isActive && stream) {
      analysisInterval = setInterval(() => {
        performFaceAnalysis();
      }, 2000); // Analyze every 2 seconds
    }
    return () => {
      if (analysisInterval) {
        clearInterval(analysisInterval);
      }
    };
    // eslint-disable-next-line
  }, [isActive, stream]);

  const startVideo = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        },
        audio: true
      });

      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setError('');
    } catch (err) {
      console.error('Error accessing camera:', err);
      setError('Unable to access camera. Please check permissions.');
    }
  };

  const stopVideo = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const toggleVideo = () => {
    if (stream) {
      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoEnabled(videoTrack.enabled);
      }
    }
  };

  const toggleAudio = () => {
    if (stream) {
      const audioTrack = stream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsAudioEnabled(audioTrack.enabled);
      }
    }
  };

  const performFaceAnalysis = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    if (!ctx) return;

    // Set canvas size to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw current frame to canvas
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Simulate face analysis (in a real implementation, you'd use a library like face-api.js)
    const mockAnalysis = {
      eyeContact: Math.random() * 100,
      smileFrequency: Math.random() * 100,
      headMovement: Math.random() * 100,
      confidence: Math.random() * 100,
      engagement: Math.random() * 100
    };

    setAnalysis(mockAnalysis);
    if (onAnalysisUpdate) {
      onAnalysisUpdate(mockAnalysis);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 70) return 'text-green-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBg = (score) => {
    if (score >= 70) return 'bg-green-100';
    if (score >= 50) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center text-red-600 mb-4">
          <AlertTriangle className="h-6 w-6 mr-2" />
          <h3 className="text-lg font-semibold">Camera Access Required</h3>
        </div>
        <p className="text-gray-600 mb-4">{error}</p>
        <button
          onClick={startVideo}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Video Analysis</h3>
        <div className="flex space-x-2">
          <button
            onClick={toggleVideo}
            className={`p-2 rounded-lg transition-colors ${
              isVideoEnabled 
                ? 'bg-green-100 text-green-600 hover:bg-green-200' 
                : 'bg-red-100 text-red-600 hover:bg-red-200'
            }`}
          >
            {isVideoEnabled ? <Camera className="h-5 w-5" /> : <CameraOff className="h-5 w-5" />}
          </button>
          <button
            onClick={toggleAudio}
            className={`p-2 rounded-lg transition-colors ${
              isAudioEnabled 
                ? 'bg-green-100 text-green-600 hover:bg-green-200' 
                : 'bg-red-100 text-red-600 hover:bg-red-200'
            }`}
          >
            {isAudioEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Video Feed */}
        <div className="relative">
          <video
            ref={videoRef}
            autoPlay
            muted
            playsInline
            className="w-full h-64 bg-gray-900 rounded-lg object-cover"
          />
          <canvas
            ref={canvasRef}
            className="hidden"
          />
          {!isVideoEnabled && (
            <div className="absolute inset-0 bg-gray-900 rounded-lg flex items-center justify-center">
              <CameraOff className="h-12 w-12 text-gray-400" />
            </div>
          )}
        </div>

        {/* Analysis Results */}
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
            <div className="flex items-center">
              <Eye className="h-5 w-5 text-blue-600 mr-2" />
              <span className="text-sm font-medium">Eye Contact</span>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getScoreBg(analysis.eyeContact)} ${getScoreColor(analysis.eyeContact)}`}>
              {Math.round(analysis.eyeContact)}%
            </div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
            <div className="flex items-center">
              <Smile className="h-5 w-5 text-green-600 mr-2" />
              <span className="text-sm font-medium">Smile Frequency</span>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getScoreBg(analysis.smileFrequency)} ${getScoreColor(analysis.smileFrequency)}`}>
              {Math.round(analysis.smileFrequency)}%
            </div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
            <div className="flex items-center">
              <div className="w-5 h-5 bg-purple-600 rounded-full mr-2"></div>
              <span className="text-sm font-medium">Head Movement</span>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getScoreBg(analysis.headMovement)} ${getScoreColor(analysis.headMovement)}`}>
              {Math.round(analysis.headMovement)}%
            </div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
            <div className="flex items-center">
              <div className="w-5 h-5 bg-yellow-600 rounded-full mr-2"></div>
              <span className="text-sm font-medium">Confidence</span>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getScoreBg(analysis.confidence)} ${getScoreColor(analysis.confidence)}`}>
              {Math.round(analysis.confidence)}%
            </div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
            <div className="flex items-center">
              <div className="w-5 h-5 bg-indigo-600 rounded-full mr-2"></div>
              <span className="text-sm font-medium">Engagement</span>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getScoreBg(analysis.engagement)} ${getScoreColor(analysis.engagement)}`}>
              {Math.round(analysis.engagement)}%
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 p-3 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-800">
          <strong>Tip:</strong> Maintain good eye contact with the camera, smile naturally, and keep your head steady for better scores.
        </p>
      </div>
    </div>
  );
}