import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Target, MessageSquare, Code, Users, ChevronRight, Clock, Brain, ArrowRight } from 'lucide-react';
import { useUser } from '../contexts/UserContext';
import { JobApplicationForm } from './JobApplicationForm';
import { AuthModal } from './AuthModal';

export function InterviewSetup() {
  const { user, appUserProfile, updateAppUserProfile } = useUser();
  const navigate = useNavigate();
  const [showRegistration, setShowRegistration] = useState(false);
  const [step, setStep] = useState('intro');

  const handleGetStarted = () => {
    if (!user) {
      setShowRegistration(true);
      return;
    }
    setStep('form');
  };

  const handleJobApplicationSubmit = (data) => {
    // Update app user profile with job details
    updateAppUserProfile({
      jobRole: data.jobRole,
      jobDescription: data.jobDescription,
      companyName: data.companyName,
      resumeText: data.resumeText
    });

    const params = new URLSearchParams({
      type: data.interviewType,
      domain: data.domain,
      level: data.level,
      duration: data.duration.toString(),
      jobRole: data.jobRole,
      companyName: data.companyName
    });

    navigate(`/interview?${params.toString()}`);
  };

  if (step === 'form') {
    return (
      <JobApplicationForm 
        onSubmit={handleJobApplicationSubmit}
        onBack={() => setStep('intro')}
      />
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            AI-Powered Interview Preparation
          </h1>
          <p className="text-lg text-gray-600">
            Get personalized interview questions based on your target job role and company
          </p>
        </div>

        {/* Get Started Section */}
        <div className="text-center">
          <div className="bg-white rounded-lg shadow-lg p-8 max-w-2xl mx-auto">
            <Brain className="h-16 w-16 text-blue-600 mx-auto mb-6" />
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Ready to Practice?</h3>
            <p className="text-gray-600 mb-8">
              Provide your job details to get AI-generated questions tailored specifically for your target role and company.
            </p>
            <button
              onClick={handleGetStarted}
              className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
            >
              Get Started
              <ArrowRight className="h-5 w-5 ml-2" />
            </button>
          </div>
        </div>
      </div>

      {/* User Registration Modal */}
      {showRegistration && (
        <AuthModal onClose={() => setShowRegistration(false)} />
      )}
    </div>
  );
}