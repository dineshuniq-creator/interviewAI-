import React from 'react';
import { Clock, TrendingUp, TrendingDown, Target, MessageSquare } from 'lucide-react';

export function RealTimeTracking({
  currentQuestionIndex,
  totalQuestions,
  timeLeft,
  totalDuration,
  averageConfidence,
  averageResponseTime,
  wordsPerMinute
}) {
  // Prevent division by zero
  const progress = totalQuestions > 0 ? ((currentQuestionIndex + 1) / totalQuestions) * 100 : 0;
  const timeUsed = totalDuration * 60 - timeLeft;
  const timeProgress = totalDuration > 0 ? (timeUsed / (totalDuration * 60)) * 100 : 0;

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getConfidenceColor = (confidence) => {
    if (confidence >= 80) return 'text-green-600';
    if (confidence >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getResponseTimeColor = (time) => {
    if (time <= 120) return 'text-green-600';
    if (time <= 300) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Real-time Performance</h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="text-center">
          <Target className="h-6 w-6 text-blue-600 mx-auto mb-2" />
          <div className="text-lg font-bold text-gray-900">{Math.round(progress)}%</div>
          <div className="text-sm text-gray-600">Progress</div>
        </div>
        
        <div className="text-center">
          <Clock className="h-6 w-6 text-purple-600 mx-auto mb-2" />
          <div className="text-lg font-bold text-gray-900">{formatTime(timeLeft)}</div>
          <div className="text-sm text-gray-600">Time Left</div>
        </div>
        
        <div className="text-center">
          <TrendingUp className={`h-6 w-6 mx-auto mb-2 ${getConfidenceColor(averageConfidence)}`} />
          <div className={`text-lg font-bold ${getConfidenceColor(averageConfidence)}`}>
            {isNaN(averageConfidence) ? '-' : Math.round(averageConfidence)}%
          </div>
          <div className="text-sm text-gray-600">Avg Confidence</div>
        </div>
        
        <div className="text-center">
          <MessageSquare className={`h-6 w-6 mx-auto mb-2 ${getResponseTimeColor(averageResponseTime)}`} />
          <div className={`text-lg font-bold ${getResponseTimeColor(averageResponseTime)}`}>
            {isNaN(averageResponseTime) ? '-' : Math.round(averageResponseTime)}s
          </div>
          <div className="text-sm text-gray-600">Avg Response</div>
        </div>
      </div>

      {/* Progress Bars */}
      <div className="space-y-3">
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Interview Progress</span>
            <span>{currentQuestionIndex + 1}/{totalQuestions}</span>
          </div>
          <div className="bg-gray-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-blue-600 to-cyan-600 h-2 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-sm mb-1">
            <span>Time Usage</span>
            <span>{Math.round(timeProgress)}%</span>
          </div>
          <div className="bg-gray-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-500 ${
                timeProgress > 80 ? 'bg-red-500' : timeProgress > 60 ? 'bg-yellow-500' : 'bg-green-500'
              }`}
              style={{ width: `${Math.min(timeProgress, 100)}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Performance Tips */}
      <div className="mt-4 p-3 bg-blue-50 rounded-lg">
        <div className="text-sm text-blue-800">
          <strong>Tip:</strong> {
            averageConfidence < 60 ? 'Try to sound more confident in your responses' :
            averageResponseTime > 300 ? 'Consider being more concise in your answers' :
            wordsPerMinute !== undefined && wordsPerMinute < 100 ? 'You can elaborate more on your answers' :
            'Great job! Keep up the good work'
          }
        </div>
      </div>
    </div>
  );
}
