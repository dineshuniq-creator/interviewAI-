import React from 'react';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from 'recharts';

export function SkillsRadarChart({ sessions }) {
  // Calculate average scores across all sessions
  const calculateSkillScores = () => {
    if (!sessions || sessions.length === 0) {
      // Return sample data for demonstration
      return [
        { skill: 'Communication', score: 75, fullMark: 100 },
        { skill: 'Technical', score: 68, fullMark: 100 },
        { skill: 'Problem Solving', score: 82, fullMark: 100 },
        { skill: 'Confidence', score: 71, fullMark: 100 },
        { skill: 'Leadership', score: 65, fullMark: 100 },
        { skill: 'Analytical', score: 78, fullMark: 100 }
      ];
    }

    const totalSessions = sessions.length;
    const avgCommunication = sessions.reduce((sum, s) => sum + (s.feedback?.communication || 0), 0) / totalSessions;
    const avgTechnical = sessions.reduce((sum, s) => sum + (s.feedback?.technicalAccuracy || 0), 0) / totalSessions;
    const avgProblemSolving = sessions.reduce((sum, s) => sum + (s.feedback?.problemSolving || 0), 0) / totalSessions;
    const avgConfidence = sessions.reduce((sum, s) => sum + (s.feedback?.confidence || 0), 0) / totalSessions;

    return [
      { skill: 'Communication', score: Math.round(avgCommunication), fullMark: 100 },
      { skill: 'Technical', score: Math.round(avgTechnical), fullMark: 100 },
      { skill: 'Problem Solving', score: Math.round(avgProblemSolving), fullMark: 100 },
      { skill: 'Confidence', score: Math.round(avgConfidence), fullMark: 100 },
      { skill: 'Leadership', score: Math.round((avgCommunication + avgConfidence) / 2), fullMark: 100 },
      { skill: 'Analytical', score: Math.round((avgTechnical + avgProblemSolving) / 2), fullMark: 100 }
    ];
  };

  const data = calculateSkillScores();

  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data}>
          <PolarGrid stroke="#e5e7eb" />
          <PolarAngleAxis 
            dataKey="skill" 
            tick={{ fontSize: 12, fill: '#6b7280' }}
          />
          <PolarRadiusAxis 
            angle={90} 
            domain={[0, 100]} 
            tick={{ fontSize: 10, fill: '#9ca3af' }}
          />
          <Radar
            name="Skills"
            dataKey="score"
            stroke="#8b5cf6"
            fill="#8b5cf6"
            fillOpacity={0.2}
            strokeWidth={2}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}