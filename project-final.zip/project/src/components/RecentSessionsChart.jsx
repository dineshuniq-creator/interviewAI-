import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { BarChart as BarChartIcon } from 'lucide-react';

export function RecentSessionsChart({ sessions }) {
  // Generate sample data if no sessions exist
  const generateSampleData = () => {
    const types = ['HR', 'Technical', 'Aptitude', 'Group Discussion'];
    return types.map(type => ({
      type,
      sessions: Math.floor(Math.random() * 5) + 1,
      avgScore: Math.floor(Math.random() * 30) + 65
    }));
  };

  const data = sessions.length > 0 
    ? sessions.reduce((acc, session) => {
        const typeName = session.type.split('-').map(word => 
          word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');
        
        const existing = acc.find(item => item.type === typeName);
        if (existing) {
          existing.sessions += 1;
          existing.totalScore += session.feedback?.overall || 0;
          existing.avgScore = Math.round(existing.totalScore / existing.sessions);
        } else {
          acc.push({
            type: typeName,
            sessions: 1,
            totalScore: session.feedback?.overall || 0,
            avgScore: session.feedback?.overall || 0
          });
        }
        return acc;
      }, [])
    : generateSampleData();

  return (
    <div className="h-64">
      {data.length > 0 ? (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="type" 
              stroke="#6b7280"
              fontSize={12}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#fff',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
            />
            <Bar 
              dataKey="sessions" 
              fill="#3b82f6" 
              radius={[4, 4, 0, 0]}
              name="Sessions"
            />
          </BarChart>
        </ResponsiveContainer>
      ) : (
        <div className="flex items-center justify-center h-full text-gray-500">
          <div className="text-center">
            <BarChartIcon className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>No sessions yet</p>
          </div>
        </div>
      )}
    </div>
  );
}