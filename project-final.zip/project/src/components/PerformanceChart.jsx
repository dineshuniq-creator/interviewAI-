import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { format } from 'date-fns';
import { BarChart3 } from 'lucide-react';

export function PerformanceChart({ sessions }) {
  // Generate sample data if no sessions exist
  const generateSampleData = () => {
    const sampleData = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      
      sampleData.push({
        date: format(date, 'MMM dd'),
        score: Math.floor(Math.random() * 30) + 60 + (i * 2), // Trending upward
        sessions: Math.floor(Math.random() * 3) + 1
      });
    }
    
    return sampleData;
  };

  const data = sessions && sessions.length > 0 
    ? sessions.slice(-7).map((session) => ({
        date: format(new Date(session.startTime), 'MMM dd'),
        score: session.feedback?.overall || 0,
        sessions: 1
      }))
    : generateSampleData();

  return (
    <div className="h-64">
      {data.length > 0 ? (
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="date" 
              stroke="#6b7280"
              fontSize={12}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
              domain={[0, 100]}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#fff',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
            />
            <Line 
              type="monotone" 
              dataKey="score" 
              stroke="#3b82f6" 
              strokeWidth={3}
              dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6, stroke: '#3b82f6', strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      ) : (
        <div className="flex items-center justify-center h-full text-gray-500">
          <div className="text-center">
            <BarChart3 className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>Complete interviews to see your progress</p>
          </div>
        </div>
      )}
    </div>
  );
}