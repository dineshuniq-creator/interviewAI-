import React from 'react';
import { Mic, MicOff, Volume2, VolumeX } from 'lucide-react';

export function VoiceControls({
  isRecording,
  isSpeaking,
  speechSupported,
  onToggleRecording,
  onSpeakText,
  onStopSpeaking,
  questionText
}) {
  return (
    <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-lg">
      <div className="flex items-center space-x-2">
        <span className="text-sm font-medium text-gray-700">Voice Controls:</span>
      </div>
      
      <button
        onClick={onToggleRecording}
        disabled={!speechSupported}
        className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
          isRecording 
            ? 'bg-red-500 text-white hover:bg-red-600' 
            : speechSupported 
              ? 'bg-blue-500 text-white hover:bg-blue-600'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
        }`}
        title={!speechSupported ? 'Speech recognition not supported' : ''}
      >
        {isRecording ? <MicOff className="h-4 w-4 mr-1" /> : <Mic className="h-4 w-4 mr-1" />}
        {isRecording ? 'Stop' : 'Record'}
      </button>

      <button
        onClick={() => onSpeakText(questionText)}
        disabled={isSpeaking || !speechSupported}
        className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
          speechSupported 
            ? 'bg-green-500 text-white hover:bg-green-600 disabled:bg-green-300'
            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
        }`}
        title={!speechSupported ? 'Text-to-speech not supported' : ''}
      >
        <Volume2 className="h-4 w-4 mr-1" />
        {isSpeaking ? 'Speaking...' : 'Read Question'}
      </button>

      {isSpeaking && (
        <button
          onClick={onStopSpeaking}
          className="flex items-center px-3 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 text-sm font-medium transition-colors"
        >
          <VolumeX className="h-4 w-4 mr-1" />
          Stop
        </button>
      )}

      {!speechSupported && (
        <span className="text-xs text-gray-500">
          Voice features require Chrome/Edge browser
        </span>
      )}
    </div>
  );
}