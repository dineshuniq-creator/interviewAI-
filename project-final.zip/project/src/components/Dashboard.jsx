import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  User, Calendar, Clock, Mail, Plus, Brain, Target, Code, Users,
  TrendingUp, BarChart3, Award, Activity, BookOpen, Zap, Eye
} from 'lucide-react';
import { useUser } from '../contexts/UserContext';
import { PerformanceChart } from './PerformanceChart';
import { SkillsRadarChart } from './SkillsRadarChart';
import { RecentSessionsChart } from './RecentSessionsChart';
import { format } from 'date-fns';
import { getScoreColor, getDomainDisplayName } from '../utils/helpers';
import { AuthModal } from './AuthModal';

export function Dashboard() {
  const { user, appUserProfile, loading, sessions } = useUser();
  const [showAuthModal, setShowAuthModal] = useState(false);

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const getMembershipDuration = () => {
    if (!user?.createdAt) return 'New member';
    const createdDate = new Date(user.createdAt);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - createdDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    if (diffDays === 1) return 'Joined today';
    if (diffDays < 30) return `${diffDays} days ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  };

  // Calculate analytics from sessions
  const totalSessions = sessions.length;
  const completedSessions = sessions.filter(s => s.status === 'completed');
  const averageScore = completedSessions.length > 0 
    ? Math.round(completedSessions.reduce((sum, s) => sum + (s.feedback?.overall || 0), 0) / completedSessions.length)
    : 0;
  const totalHours = Math.round(sessions.reduce((sum, s) => sum + s.duration, 0) / 60 * 10) / 10;
  const improvementRate = completedSessions.length >= 2 
    ? (completedSessions[completedSessions.length - 1].feedback?.overall || 0) - (completedSessions[0].feedback?.overall || 0)
    : 0;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <Brain className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Welcome to InterviewAI</h1>
            <p className="text-gray-600 mb-6">Please sign in to access your dashboard</p>
            <button
              onClick={() => setShowAuthModal(true)}
              className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Sign In
            </button>
          </div>
        </div>
        {showAuthModal && (
          <AuthModal onClose={() => setShowAuthModal(false)} />
        )}
      </>
    );
  }

  const interviewTypes = [
    {
      type: 'hr',
      name: 'HR Interview',
      description: 'Behavioral and cultural fit questions',
      icon: User,
      color: 'bg-gradient-to-br from-blue-500 to-blue-600',
      hoverColor: 'hover:from-blue-600 hover:to-blue-700'
    },
    {
      type: 'technical',
      name: 'Technical Round',
      description: 'Role-specific technical expertise',
      icon: Code,
      color: 'bg-gradient-to-br from-red-500 to-red-600',
      hoverColor: 'hover:from-red-600 hover:to-red-700'
    },
    {
      type: 'aptitude',
      name: 'Aptitude Test',
      description: 'Logical reasoning and analytical thinking',
      icon: Target,
      color: 'bg-gradient-to-br from-purple-500 to-purple-600',
      hoverColor: 'hover:from-purple-600 hover:to-purple-700'
    },
    {
      type: 'group-discussion',
      name: 'Group Discussion',
      description: 'Leadership and communication skills',
      icon: Users,
      color: 'bg-gradient-to-br from-green-500 to-green-600',
      hoverColor: 'hover:from-green-600 hover:to-green-700'
    }
  ];

  return (
    <div className="min-h-screen py-8 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
          <div>
           <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Hi {user?.name || "InterviewAI"} 👋
            </h1>
            <p className="text-lg text-gray-600">
              Ready to practice your interview skills today?
            </p>
          </div>
        </div>

        {/* Analytics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Sessions</p>
                <p className="text-3xl font-bold text-gray-900">{totalSessions}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Average Score</p>
                <p className="text-3xl font-bold text-gray-900">{averageScore}%</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Award className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Practice Hours</p>
                <p className="text-3xl font-bold text-gray-900">{totalHours}h</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Activity className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-yellow-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Improvement</p>
                <p className={`text-3xl font-bold ${improvementRate >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {improvementRate > 0 ? '+' : ''}{improvementRate}%
                </p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-blue-600" />
              Performance Trends
            </h3>
            <PerformanceChart sessions={completedSessions} />
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Target className="h-5 w-5 mr-2 text-purple-600" />
              Skills Assessment
            </h3>
            <SkillsRadarChart sessions={completedSessions} />
          </div>
        </div>

        {/* Performance by Interview Type Chart */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <BarChart3 className="h-5 w-5 mr-2 text-green-600" />
            Performance by Interview Type
          </h3>
          <RecentSessionsChart sessions={sessions.slice(-10)} />
        </div>

        {/* Recent Interview Sessions Table */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
            <Activity className="h-5 w-5 mr-2 text-indigo-600" />
            Recent Interview Sessions
          </h3>
          
          {sessions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full table-auto">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date & Time
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Interview Type
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Domain
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Duration
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Score
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {sessions.slice(-10).reverse().map((session, index) => (
                    <tr key={session.id || index} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {format(new Date(session.startTime), 'MMM dd, yyyy')}
                        </div>
                        <div className="text-xs text-gray-500">
                          {format(new Date(session.startTime), 'hh:mm a')}
                        </div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${
                            session.type === 'hr' ? 'bg-blue-100 text-blue-600' :
                            session.type === 'technical' ? 'bg-red-100 text-red-600' :
                            session.type === 'aptitude' ? 'bg-purple-100 text-purple-600' :
                            'bg-green-100 text-green-600'
                          }`}>
                            {session.type === 'hr' ? <User className="h-4 w-4" /> :
                             session.type === 'technical' ? <Code className="h-4 w-4" /> :
                             session.type === 'aptitude' ? <Target className="h-4 w-4" /> :
                             <Users className="h-4 w-4" />}
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900 capitalize">
                              {session.type.replace('-', ' ')}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span className="text-sm text-gray-900">
                          {getDomainDisplayName(session.domain)}
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="flex items-center text-sm text-gray-900">
                          <Clock className="h-4 w-4 mr-1 text-gray-400" />
                          {session.duration}m
                        </div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        {session.feedback ? (
                          <div className="flex items-center">
                            <span className={`text-lg font-bold ${getScoreColor(session.feedback.overall)}`}>
                              {session.feedback.overall}%
                            </span>
                            <div className="ml-2 w-16 bg-gray-200 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${
                                  session.feedback.overall >= 80 ? 'bg-green-500' :
                                  session.feedback.overall >= 60 ? 'bg-yellow-500' :
                                  'bg-red-500'
                                }`}
                                style={{ width: `${session.feedback.overall}%` }}
                              ></div>
                            </div>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-500">No score</span>
                        )}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          session.status === 'completed' ? 'bg-green-100 text-green-800' :
                          session.status === 'in-progress' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {session.status.replace('-', ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        {session.status === 'completed' && session.feedback ? (
                          <Link
                            to={`/results/${session.id || (session && session._id)}`}
                            className="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors text-sm"
                          >
                            <Eye className="h-3 w-3 mr-1" />
                            View Results
                          </Link>
                        ) : (
                          <span className="text-xs text-gray-400">No results</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12">
              <Activity className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h4 className="text-lg font-medium text-gray-900 mb-2">No Interview Sessions Yet</h4>
              <p className="text-gray-500 mb-6">Start your first interview to see your session history here.</p>
              <Link
                to="/setup"
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="h-4 w-4 mr-2" />
                Start First Interview
              </Link>
            </div>
          )}
        </div>
        {/* User Profile Card */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
            <User className="h-5 w-5 mr-2 text-indigo-600" />
            Your Profile
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <User className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">{user.name}</div>
                <div className="text-sm text-gray-600">Full Name</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Mail className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">{user.email}</div>
                <div className="text-sm text-gray-600">Email Address</div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Calendar className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <div className="font-medium text-gray-900">{getMembershipDuration()}</div>
                <div className="text-sm text-gray-600">Member Since</div>
              </div>
            </div>
          </div>
        </div>

        {/* Start Interview Section */}
        <div className="bg-white rounded-xl shadow-md p-8 mb-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center justify-center">
              <Zap className="h-6 w-6 mr-2 text-yellow-500" />
              Quick Start Interview
            </h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Choose an interview type and start practicing immediately
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {interviewTypes.map((type) => (
              <Link
                key={type.type}
                to={`/interview?type=${type.type}&domain=software-engineering&level=fresher&duration=30&jobRole=Software Engineer&companyName=Tech Company`}
                className={`group relative overflow-hidden ${type.color} ${type.hoverColor} text-white rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-xl`}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                <div className="relative p-6 text-center">
                  <div className="flex items-center justify-center mb-4">
                    <type.icon className="h-8 w-8" />
                  </div>
                  <h4 className="font-semibold text-lg mb-2">{type.name}</h4>
                  <p className="text-sm opacity-90 leading-relaxed">{type.description}</p>
                  <div className="mt-4 inline-flex items-center text-sm font-medium">
                    Start Now
                    <Plus className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
          
          <div className="text-center mt-6">
            <Link
              to="/setup"
              className="inline-flex items-center px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <Target className="h-5 w-5 mr-2" />
              Custom Setup
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}