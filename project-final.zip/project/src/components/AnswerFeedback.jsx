import React, { useEffect, useState } from "react";
import { geminiAIService } from "../utils/geminiAI";

export default function AnswerFeedback({ currentAnswer }) {
  const [feedback, setFeedback] = useState(
    "✍️ Begin typing or use your voice. Even small steps are progress!"
  );
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let isCancelled = false;
    let debounceTimer;

    const fetchFeedback = async () => {
      if (!currentAnswer || !currentAnswer.trim()) {
        setFeedback(
          "✍️ Begin typing or use your voice. Even small steps are progress!"
        );
        return;
      }

      setLoading(true);
      try {
        const response = await geminiAIService.getMotivation(currentAnswer);

        if (!isCancelled && response?.feedback) {
          setFeedback(response.feedback);
        }
      } catch (error) {
        if (!isCancelled) {
          console.error("Motivation fetch failed:", error);
          setFeedback(
            "⚡ Keep going! Every word you add makes your answer stronger."
          );
        }
      } finally {
        if (!isCancelled) setLoading(false);
      }
    };

    // Debounce 500ms
    debounceTimer = setTimeout(fetchFeedback, 500);

    return () => {
      isCancelled = true;
      clearTimeout(debounceTimer);
    };
  }, [currentAnswer]);

  return (
    <div
      className={`p-3 mt-2 rounded-lg border text-sm ${
        loading
          ? "bg-gray-50 border-gray-200 text-gray-600"
          : "bg-blue-50 border-blue-200 text-blue-700"
      }`}
    >
      {loading ? "✨ Thinking of feedback..." : feedback}
    </div>
  );
}
