import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Clock, Mic, MicOff, Send, SkipForward, Volume2, VolumeX, Loader } from 'lucide-react';
import { useUser } from '../contexts/UserContext';
import { geminiAIService } from '../utils/geminiAI';
import { speechService } from '../utils/speechService';
import { calculateTimeSpent } from '../utils/helpers';
import { RealTimeTracking } from './RealTimeTracking';
import { VoiceControls } from './VoiceControls';
import { VideoAnalysis } from './VideoAnalysis';
import AnswerFeedback from "./AnswerFeedback"; 

export function InterviewSession() {
  const { user, appUserProfile, addSession } = useUser();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const type = searchParams.get('type');
  const domain = searchParams.get('domain');
  const level = searchParams.get('level') || 'fresher';
  const totalDuration = Number(searchParams.get('duration')) || 30;
  const jobRole = searchParams.get('jobRole') || '';
  const companyName = searchParams.get('companyName') || '';
  const jobDescription = appUserProfile?.jobDescription || '';

  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [responses, setResponses] = useState([]);
  const [currentAnswer, setCurrentAnswer] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [timeLeft, setTimeLeft] = useState(totalDuration * 60);
  const [questionStartTime, setQuestionStartTime] = useState(new Date());
  const [confidence, setConfidence] = useState(75);
  const [sessionStartTime] = useState(new Date());
  const [isLoadingQuestions, setIsLoadingQuestions] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechSupported] = useState(speechService.isSupported());
  const [voiceInput, setVoiceInput] = useState('');
  const [isProcessingVoice, setIsProcessingVoice] = useState(false);
  const [autoReadQuestions, setAutoReadQuestions] = useState(true);
  const [videoAnalysis, setVideoAnalysis] = useState(null);

  useEffect(() => {
    if (!user || !type || !domain) {
      navigate('/setup');
      return;
    }

    const generateQuestions = async () => {
      setIsLoadingQuestions(true);
      try {
        const generatedQuestions = await geminiAIService.generateQuestions(
          type, domain, jobRole, jobDescription, companyName, level, 5
        );
        setQuestions(generatedQuestions);
        setQuestionStartTime(new Date());
      } finally {
        setIsLoadingQuestions(false);
      }
    };

    generateQuestions();
  }, [user, type, domain, jobRole, jobDescription, companyName, level, navigate]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          handleEndInterview();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (autoReadQuestions && questions.length > 0 && !isLoadingQuestions) {
      const currentQuestion = questions[currentQuestionIndex];
      if (currentQuestion) {
        speakQuestion(currentQuestion.text);
      }
    }
  }, [currentQuestionIndex, questions, autoReadQuestions, isLoadingQuestions]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const speakQuestion = (text) => {
    if (!speechSupported) return;
    setIsSpeaking(true);
    speechService.speak(text, () => setIsSpeaking(false));
  };

  const stopSpeaking = () => {
    speechService.stopSpeaking();
    setIsSpeaking(false);
  };

  const handleVideoAnalysisUpdate = (analysis) => {
    setVideoAnalysis(analysis);
  };

  const toggleRecording = () => {
    if (!speechSupported) {
      alert('Speech recognition is not supported in your browser');
      return;
    }

    if (isRecording) {
      speechService.stopListening();
      setIsRecording(false);
      setIsProcessingVoice(false);
    } else {
      setIsRecording(true);
      setIsProcessingVoice(true);
      speechService.startListening(
        (text, isFinal) => {
          setVoiceInput(text);
          if (isFinal) {
            setCurrentAnswer(prev => prev + (prev ? ' ' : '') + text);
            setVoiceInput('');
            setIsProcessingVoice(false);
          }
        },
        (error) => {
          console.error('Speech recognition error:', error);
          setIsRecording(false);
          setIsProcessingVoice(false);
        }
      );
    }
  };

  const handleSubmitAnswer = () => {
    if (!currentAnswer.trim()) return;

    const response = {
      questionId: questions[currentQuestionIndex].id,
      answer: currentAnswer.trim(),
      timeSpent: calculateTimeSpent(questionStartTime, new Date()),
      confidence,
      timestamp: new Date()
    };

    const newResponses = [...responses, response];
    setResponses(newResponses);
    setCurrentAnswer('');
    setConfidence(75);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setQuestionStartTime(new Date());
    } else {
      handleEndInterview(newResponses);
    }
  };

  const handleSkipQuestion = () => {
    const response = {
      questionId: questions[currentQuestionIndex].id,
      answer: '',
      timeSpent: calculateTimeSpent(questionStartTime, new Date()),
      confidence: 0,
      timestamp: new Date()
    };

    const newResponses = [...responses, response];
    setResponses(newResponses);
    setCurrentAnswer('');

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setQuestionStartTime(new Date());
    } else {
      handleEndInterview(newResponses);
    }
  };

  const handleEndInterview = async (finalResponses) => {
    const sessionResponses = finalResponses || responses;
    const feedback = await geminiAIService.generateFeedback(sessionResponses, questions, type, jobRole, jobDescription);

    const sessionData = {
      userId: user.id,
      type,
      domain,
      questions,
      responses: sessionResponses,
      feedback,
      startTime: sessionStartTime,
      endTime: new Date(),
      status: 'completed',
      duration: Math.floor((new Date().getTime() - sessionStartTime.getTime()) / (1000 * 60)),
      jobRole,
      companyName
    };

    try {
      const savedSession = await addSession(sessionData);
      navigate(`/results/${savedSession._id || savedSession.id}`);
    } catch (error) {
      console.error('Failed to save session:', error);
      navigate('/dashboard');
    }
  };

  if (!user || !type || !domain || isLoadingQuestions) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader className="h-12 w-12 text-blue-600 mx-auto mb-4 animate-spin" />
          <p className="text-gray-600">
            {isLoadingQuestions ? 'Generating personalized questions...' : 'Setting up your interview...'}
          </p>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];

  const averageConfidence = responses.length > 0
    ? responses.reduce((sum, r) => sum + r.confidence, 0) / responses.length
    : confidence;

  const averageResponseTime = responses.length > 0
    ? responses.reduce((sum, r) => sum + r.timeSpent, 0) / responses.length
    : 0;

  const wordsPerMinute = currentAnswer.split(' ').filter(word => word.length > 0).length;

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {jobRole} - {companyName}
              </h1>
              <h2 className="text-lg text-gray-600">
                {type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')} Interview
              </h2>
              <p className="text-sm text-gray-500">Question {currentQuestionIndex + 1} of {questions.length}</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">{formatTime(timeLeft)}</div>
              <div className="text-sm text-gray-500">Time Remaining</div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mt-4">
            <div className="bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-blue-600 to-cyan-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Real-time Tracking */}
        <RealTimeTracking
          currentQuestionIndex={currentQuestionIndex}
          totalQuestions={questions.length}
          timeLeft={timeLeft}
          totalDuration={totalDuration}
          averageConfidence={averageConfidence}
          averageResponseTime={averageResponseTime}
          wordsPerMinute={wordsPerMinute}
        />

        {/* Video Analysis */}
        {type === 'hr' && (
          <VideoAnalysis
            isActive={true}
            onAnalysisUpdate={handleVideoAnalysisUpdate}
          />
        )}

        {/* Question Card */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-6">
          {/* Question Controls */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <label className="flex items-center space-x-2 text-sm text-gray-600">
                <input
                  type="checkbox"
                  checked={autoReadQuestions}
                  onChange={(e) => setAutoReadQuestions(e.target.checked)}
                  className="rounded"
                />
                <span>Auto-read questions</span>
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => speakQuestion(currentQuestion.text)}
                disabled={isSpeaking || !speechSupported}
                className="flex items-center px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 disabled:opacity-50 transition-colors"
              >
                <Volume2 className="h-4 w-4 mr-1" />
                {isSpeaking ? 'Speaking...' : 'Read Question'}
              </button>
              {isSpeaking && (
                <button
                  onClick={stopSpeaking}
                  className="flex items-center px-3 py-1 text-sm bg-red-100 text-red-700 rounded-md hover:bg-red-200 transition-colors"
                >
                  <VolumeX className="h-4 w-4 mr-1" />
                  Stop
                </button>
              )}
            </div>
          </div>

          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0 w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold text-lg">
              {currentQuestionIndex + 1}
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-3">
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  currentQuestion.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                  currentQuestion.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {currentQuestion.difficulty.toUpperCase()}
                </span>
                <span className="text-sm text-gray-500">
                  <Clock className="inline h-3 w-3 mr-1" />
                  {Math.floor(currentQuestion.timeLimit / 60)} min suggested
                </span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 leading-relaxed">
                {currentQuestion.text}
              </h3>
            </div>
          </div>
        </div>

        {/* Voice Controls */}
        <VoiceControls
          isRecording={isRecording}
          isSpeaking={isSpeaking}
          speechSupported={speechSupported}
          onToggleRecording={toggleRecording}
          onSpeakText={speakQuestion}
          onStopSpeaking={stopSpeaking}
          questionText={currentQuestion.text}
        />

        {/* Response Area */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Response</h3>
          <AnswerFeedback currentAnswer={currentAnswer + (voiceInput ? ' ' + voiceInput : '')} />

          {isRecording && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center text-red-700">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-2"></div>
                <span className="text-sm font-medium">
                  {isProcessingVoice ? 'Listening...' : 'Processing speech...'}
                </span>
                {voiceInput && <span className="ml-2 text-sm">"{voiceInput}"</span>}
              </div>
            </div>
          )}
           
          <div className="space-y-4">
            <textarea
              value={currentAnswer}
              onChange={(e) => setCurrentAnswer(e.target.value)}
              placeholder="Type your answer here or use voice input..."
              className="w-full h-40 p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                How confident are you? ({confidence}%)
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={confidence}
                onChange={(e) => setConfidence(Number(e.target.value))}
                className="w-full"
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex space-x-4">
                <button
                  onClick={toggleRecording}
                  disabled={!speechSupported}
                  className={`flex items-center px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                    isRecording 
                      ? 'bg-red-500 text-white hover:bg-red-600' 
                      : speechSupported 
                        ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }`}
                  title={!speechSupported ? 'Speech recognition not supported in your browser' : ''}
                >
                  {isRecording ? <MicOff className="h-4 w-4 mr-2" /> : <Mic className="h-4 w-4 mr-2" />}
                  {isRecording ? 'Stop Recording' : speechSupported ? 'Voice Input' : 'Voice Unavailable'}
                </button>

                <button
                  onClick={handleSkipQuestion}
                  className="flex items-center px-4 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300 transition-colors"
                >
                  <SkipForward className="h-4 w-4 mr-2" />
                  Skip Question
                </button>
              </div>

              <button
                onClick={handleSubmitAnswer}
                disabled={!currentAnswer.trim()}
                className="flex items-center px-6 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg font-medium hover:from-blue-700 hover:to-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
              >
                <Send className="h-4 w-4 mr-2" />
                {currentQuestionIndex === questions.length - 1 ? 'Finish Interview' : 'Next Question'}
              </button>
            </div>
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={() => handleEndInterview()}
            className="text-red-600 hover:text-red-700 text-sm font-medium"
          >
            End Interview Early
          </button>
        </div>
      </div>
    </div>
  );
}
