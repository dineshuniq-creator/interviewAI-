import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Brain, Users, Target, Code, MessageSquare, BarChart3, Clock, Star } from 'lucide-react';
import { useUser } from '../contexts/UserContext';
import { AuthModal } from './AuthModal';

export function LandingPage() {
  const navigate = useNavigate();
  const { user } = useUser();
  const [showAuthModal, setShowAuthModal] = React.useState(false);

  const features = [
    {
      icon: Brain,
      title: 'AI-Powered Questions',
      description: 'Dynamic question generation tailored to your specific role and experience level'
    },
    {
      icon: Users,
      title: 'Multiple Interview Types',
      description: 'Practice aptitude, HR, technical, and group discussion scenarios'
    },
    {
      icon: BarChart3,
      title: 'Performance Analytics',
      description: 'Detailed feedback and progress tracking to monitor your improvement'
    },
    {
      icon: Clock,
      title: 'Real-time Simulation',
      description: 'Realistic interview environment with time management and pressure simulation'
    }
  ];

  const interviewTypes = [
    {
      icon: Target,
      name: 'Aptitude',
      description: 'Logical reasoning, quantitative aptitude, and analytical skills',
      color: 'bg-purple-500'
    },
    {
      icon: MessageSquare,
      name: 'HR Interview',
      description: 'Behavioral questions, company culture fit, and soft skills',
      color: 'bg-blue-500'
    },
    {
      icon: Code,
      name: 'Technical',
      description: 'Role-specific technical questions and coding challenges',
      color: 'bg-red-500'
    },
    {
      icon: Users,
      name: 'Group Discussion',
      description: 'Leadership, teamwork, and communication in group settings',
      color: 'bg-green-500'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center space-x-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-full text-sm font-medium mb-8">
            <Star className="h-4 w-4" />
            <span>AI-Powered Interview Preparation</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Master Your Next
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-600">
              Interview
            </span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
            Practice with AI-generated questions, receive instant feedback, and track your progress. 
            Build confidence with realistic interview simulations tailored to your career goals.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {user ? (
              <Link
                to="/dashboard"
                className="inline-flex items-center justify-center px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
              >
                Go to Dashboard
              </Link>
            ) : (
              <button
                onClick={() => setShowAuthModal(true)}
                className="inline-flex items-center justify-center px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
              >
                Get Started Free
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose InterviewAI?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Leverage cutting-edge AI technology to prepare for interviews with personalized, 
              intelligent feedback and realistic simulation environments.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center group">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-lg mb-4 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                  <feature.icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Interview Types */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Interview Types
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Practice across different interview formats to build comprehensive skills
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {interviewTypes.map((type, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-all duration-300 group">
                <div className={`inline-flex items-center justify-center w-12 h-12 ${type.color} text-white rounded-lg mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <type.icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{type.name}</h3>
                <p className="text-gray-600 text-sm">{type.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {showAuthModal && (
        <AuthModal onClose={() => setShowAuthModal(false)} />
      )}
    </div>
  );
}