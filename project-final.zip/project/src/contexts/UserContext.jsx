import React, { createContext, useContext, useState, useEffect } from "react";
import { apiService } from "../services/api";

// ----------------- Context -----------------
const UserContext = createContext(undefined);

export function UserContextProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sessions, setSessions] = useState([]);
  const [appUserProfile, setAppUserProfile] = useState({});

  // ----------------- Auth Check -----------------
  useEffect(() => {
    checkAuthStatus();
    // eslint-disable-next-line
  }, []);

  const checkAuthStatus = async () => {
    try {
      const token = localStorage.getItem("authToken");
      if (token) {
        const userData = await apiService.getUserProfile();
        setUser(userData.user);
        await getSessions(userData.user.id || userData.user._id);
      }
    } catch (error) {
      console.error("Auth check failed:", error);
      localStorage.removeItem("authToken");
    } finally {
      setLoading(false);
    }
  };

  // ----------------- Auth Actions -----------------
  const login = async (email, password) => {
    try {
      const response = await apiService.login(email, password);
      setUser(response.user);
      await getSessions(response.user.id || response.user._id);
    } catch (error) {
      throw error;
    }
  };

  const register = async (name, email, password) => {
    try {
      const response = await apiService.register({ name, email, password });
      setUser(response.user);
      await getSessions(response.user.id || response.user._id);
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    apiService.logout();
    setUser(null);
    setSessions([]);
    setAppUserProfile({});
  };

  // ----------------- Session Actions -----------------
  const getSessions = async (userId) => {
    const id = userId || user?._id || user?.id;
    if (!id) return;

    try {
      const response = await apiService.getSessions(id);
      setSessions(response.sessions || []);
    } catch (error) {
      console.error("Failed to fetch sessions:", error);
      setSessions([]);
    }
  };

const addSession = async (session) => {
  // 🔹 Count answered questions
  const answeredCount = session?.responses
    ? session.responses.filter((r) => r.answer && r.answer.trim()).length
    : 0;

  // 🔹 If no answers → do not save anywhere
  if (answeredCount === 0) {
    console.warn("Skipping save: no answers provided.");
    return null; // nothing stored in DB or local state
  }

  // 🔹 Otherwise, save normally via API
  try {
    const response = await apiService.addSession(session);
    setSessions((prev) => [...prev, response.session]);
    return response.session;
  } catch (error) {
    console.error("Failed to save session:", error);

    // Fallback: assign local id and store in memory only
    const sessionWithId = {
      ...session,
      id:
        session.id ||
        `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };
    setSessions((prev) => [...prev, sessionWithId]);
    return sessionWithId;
  }
};



  // ----------------- Profile Actions -----------------
  const updateAppUserProfile = (profile) => {
    setAppUserProfile((prev) => ({ ...prev, ...profile }));
  };

  // ----------------- Effect: keep sessions in sync -----------------
  useEffect(() => {
    if (user) {
      getSessions(user._id || user.id);
    }
    // eslint-disable-next-line
  }, [user]);

  // ----------------- Provider -----------------
  return (
    <UserContext.Provider
      value={{
        user,
        loading,
        sessions,
        appUserProfile,
        login,
        register,
        logout,
        addSession,
        getSessions,
        updateAppUserProfile,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

// ----------------- Hook -----------------
export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserContextProvider");
  }
  return context;
}
