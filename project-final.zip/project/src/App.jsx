import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { UserContextProvider } from './contexts/UserContext.jsx';
import { LandingPage } from './components/LandingPage.jsx';
import { Dashboard } from './components/Dashboard.jsx';
import { InterviewSetup } from './components/InterviewSetup.jsx';
import { InterviewSession } from './components/InterviewSession.jsx';
import { ResultsPage } from './components/ResultsPage.jsx';
import { Header } from './components/Header.jsx';

function App() {
  return (
    <UserContextProvider>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
          <Header />
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/setup" element={<InterviewSetup />} />
            <Route path="/interview" element={<InterviewSession />} />
            <Route path="/results/:sessionId" element={<ResultsPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </Router>
    </UserContextProvider>
  );
}

export default App;