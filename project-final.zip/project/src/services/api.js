const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

class ApiService {
  getAuthHeaders() {
    const token = localStorage.getItem('authToken');
    return {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` })
    };
  }

  // -------------------------
  // 🔹 AUTH
  // -------------------------

  async register(userData) {
    const response = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: this.getAuthHeaders(),
      body: JSON.stringify(userData),
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.message || 'Registration failed');

    if (data.token) {
      localStorage.setItem('authToken', data.token);
    }

    return data;
  }

  async login(email, password) {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: this.getAuthHeaders(),
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.message || 'Login failed');

    if (data.token) {
      localStorage.setItem('authToken', data.token);
    }

    return data;
  }

  async getUserProfile() {
    const response = await fetch(`${API_BASE_URL}/auth/profile`, {
      headers: this.getAuthHeaders(),
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.message || 'Failed to fetch user profile');

    return data;
  }

  logout() {
    localStorage.removeItem('authToken');
  }

  // -------------------------
  // 🔹 HEALTH CHECK
  // -------------------------

  async checkHealth() {
    try {
      const response = await fetch(`${API_BASE_URL}/health`);
      return response.ok;
    } catch {
      return false;
    }
  }

  // -------------------------
  // 🔹 SESSIONS (Interview)
  // -------------------------

  async getSessions() {
    const response = await fetch(`${API_BASE_URL}/interview/sessions`, {
      headers: this.getAuthHeaders(),
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.message || 'Failed to fetch sessions');

    return data;
  }

  async addSession(session) {
    const answeredCount = session?.responses
      ? session.responses.filter(r => r.answer && r.answer.trim()).length
      : 0;

    if (answeredCount === 0) {
      throw new Error("Cannot save session: no answers provided");
    }

    const response = await fetch(`${API_BASE_URL}/interview/sessions`, {
      method: 'POST',
      headers: this.getAuthHeaders(),
      body: JSON.stringify(session),
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.message || 'Failed to save session');

    return data;
  }
}

export const apiService = new ApiService();
