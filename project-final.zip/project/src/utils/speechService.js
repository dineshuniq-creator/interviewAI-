export class SpeechService {
  constructor() {
    this.recognition = null;
    this.synthesis = window.speechSynthesis;
    this.isListening = false;

    // Initialize speech recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';
    }
  }

  isSupported() {
    return this.recognition !== null && 'speechSynthesis' in window;
  }

  startListening(onResult, onError) {
    if (!this.recognition || this.isListening) {
      if (onError) onError('Speech recognition not supported or already listening');
      return;
    }

    this.isListening = true;

    this.recognition.onresult = (event) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        // ✅ Fix: Access the first alternative transcript
        const transcript = event.results[i][0].transcript || '';

        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }

      console.log('Speech result:', { finalTranscript, interimTranscript });

      if (finalTranscript.trim() || interimTranscript.trim()) {
        onResult(finalTranscript.trim() || interimTranscript.trim(), !!finalTranscript.trim());
      } else {
        if (onError) onError('No speech detected. Please try again.');
      }
    };

    this.recognition.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      this.isListening = false;
      if (onError) onError(event.error);
    };

    this.recognition.onend = () => {
      this.isListening = false;
    };

    try {
      this.recognition.start();
    } catch (error) {
      this.isListening = false;
      if (onError) onError('Failed to start speech recognition');
    }
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
      this.isListening = false;
    }
  }

  speak(text, onEnd) {
    if (!text || !text.trim()) return;

    this.synthesis.cancel(); // stop ongoing speech

    const utterance = new window.SpeechSynthesisUtterance(text);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 0.8;

    if (onEnd) {
      utterance.onend = onEnd;
    }

    this.synthesis.speak(utterance);
  }

  stopSpeaking() {
    this.synthesis.cancel();
  }

  getListeningStatus() {
    return this.isListening;
  }
}

export const speechService = new SpeechService();
