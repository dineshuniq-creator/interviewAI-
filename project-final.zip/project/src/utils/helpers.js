export function generateSessionId() {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function generateUserId() {
  return `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function formatDuration(minutes) {
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  
  if (hours > 0) {
    return `${hours}h ${remainingMinutes}m`;
  }
  return `${remainingMinutes}m`;
}

export function calculateTimeSpent(startTime, endTime) {
  return Math.floor((endTime.getTime() - startTime.getTime()) / 1000);
}

export function getInterviewTypeColor(type) {
  const colors = {
    'aptitude': 'bg-purple-500',
    'group-discussion': 'bg-green-500',
    'hr': 'bg-blue-500',
    'technical': 'bg-red-500'
  };
  return colors[type];
}

export function getDomainDisplayName(domain) {
  const names = {
    'software-engineering': 'Software Engineering',
    'data-science': 'Data Science',
    'product-management': 'Product Management',
    'marketing': 'Marketing',
    'finance': 'Finance',
    'sales': 'Sales',
    'operations': 'Operations',
    'design': 'Design'
  };
  return names[domain];
}

export function getScoreColor(score) {
  if (score >= 80) return 'text-green-600';
  if (score >= 60) return 'text-yellow-600';
  return 'text-red-600';
}

export function getScoreBadgeColor(score) {
  if (score >= 80) return 'bg-green-100 text-green-800';
  if (score >= 60) return 'bg-yellow-100 text-yellow-800';
  return 'bg-red-100 text-red-800';
}