export class MockAIService {
  constructor() {
    this.questionBank = {
      aptitude: {
        'software-engineering': [
          'What is the time complexity of binary search?',
          'Explain the difference between stack and heap memory.',
          'What are the principles of object-oriented programming?',
          'How would you optimize a slow database query?',
          'Describe the software development lifecycle.',
        ],
        'data-science': [
          'What is the difference between supervised and unsupervised learning?',
          'Explain the concept of overfitting in machine learning.',
          'How would you handle missing data in a dataset?',
          'What are the key metrics for evaluating a classification model?',
          'Describe the process of feature engineering.',
        ]
      },
      hr: {
        'software-engineering': [
          'Tell me about yourself and your passion for software development.',
          'Why do you want to work for our company?',
          'Describe a challenging project you worked on.',
          'How do you handle work pressure and tight deadlines?',
          'Where do you see yourself in 5 years?',
        ],
        'data-science': [
          'What interests you most about data science?',
          'How do you stay updated with the latest trends in data science?',
          'Describe a time when you had to explain complex data insights to non-technical stakeholders.',
          'How do you handle uncertainty in data analysis?',
          'What motivates you in your data science career?',
        ]
      },
      technical: {
        'software-engineering': [
          'Design a URL shortener like bit.ly. What are the key components?',
          'Implement a function to reverse a linked list.',
          'How would you design a chat application for millions of users?',
          'Explain how you would implement caching in a web application.',
          'Write an algorithm to find the shortest path in a graph.',
        ],
        'data-science': [
          'How would you design an A/B testing framework?',
          'Implement a recommendation system for an e-commerce platform.',
          'Explain how you would build a real-time fraud detection system.',
          'Design a data pipeline for processing streaming data.',
          'How would you approach building a customer churn prediction model?',
        ]
      },
      'group-discussion': {
        'software-engineering': [
          'Should artificial intelligence replace human developers?',
          'Is remote work the future of software development?',
          'How important is open source software for innovation?',
          'Should coding bootcamps replace computer science degrees?',
          'Is privacy more important than personalization in apps?',
        ],
        'data-science': [
          'Will AI eventually make data scientists obsolete?',
          'Should companies prioritize data collection or user privacy?',
          'Is big data always better than small, high-quality datasets?',
          'How ethical is algorithmic decision making in hiring?',
          'Should data science be regulated by government policies?',
        ]
      }
    };
  }

  generateQuestions(type, domain, count = 5) {
    const questionPool = this.questionBank[type]?.[domain] || this.questionBank[type]?.['software-engineering'] || [];
    
    return Array.from({ length: count }, (_, index) => ({
      id: `q_${Date.now()}_${index}`,
      text: questionPool[index % questionPool.length] || `Sample ${type} question for ${domain}`,
      type: this.getQuestionType(type),
      difficulty: this.getRandomDifficulty(),
      timeLimit: this.getTimeLimit(type),
      expectedKeywords: this.generateExpectedKeywords(type, domain)
    }));
  }

  getQuestionType(interviewType) {
    switch (interviewType) {
      case 'technical': return 'coding';
      case 'aptitude': return 'analytical';
      case 'hr': return 'behavioral';
      case 'group-discussion': return 'behavioral';
      default: return 'text';
    }
  }

  getRandomDifficulty() {
    const difficulties = ['easy', 'medium', 'hard'];
    return difficulties[Math.floor(Math.random() * difficulties.length)];
  }

  getTimeLimit(type) {
    switch (type) {
      case 'technical': return 600; // 10 minutes
      case 'aptitude': return 300; // 5 minutes
      case 'group-discussion': return 480; // 8 minutes
      case 'hr': return 240; // 4 minutes
      default: return 300;
    }
  }

  generateExpectedKeywords(type, domain) {
    const keywordBank = {
      'software-engineering': ['algorithm', 'data structure', 'optimization', 'scalability', 'architecture'],
      'data-science': ['machine learning', 'statistics', 'data analysis', 'model', 'prediction'],
    };
    return keywordBank[domain] || ['professional', 'experience', 'skills', 'teamwork', 'problem-solving'];
  }

  generateFeedback(responses, questions, type) {
    // Simulate AI analysis
    const scores = {
      communication: this.analyzeCommunication(responses),
      technicalAccuracy: this.analyzeTechnicalAccuracy(responses, questions, type),
      problemSolving: this.analyzeProblemSolving(responses),
      confidence: this.analyzeConfidence(responses)
    };

    const overall = Math.round((scores.communication + scores.technicalAccuracy + scores.problemSolving + scores.confidence) / 4);

    return {
      overall,
      ...scores,
      strengths: this.generateStrengths(scores),
      weaknesses: this.generateWeaknesses(scores),
      suggestions: this.generateSuggestions(scores, type)
    };
  }

  analyzeCommunication(responses) {
    const avgLength = responses.reduce((sum, r) => sum + r.answer.length, 0) / responses.length;
    const lengthScore = Math.min(avgLength / 20, 100); // Normalize based on response length
    return Math.round(lengthScore * 0.7 + Math.random() * 30 + 50); // Simulate realistic scoring
  }

  analyzeTechnicalAccuracy(responses, questions, type) {
    if (type === 'hr' || type === 'group-discussion') {
      return Math.round(Math.random() * 20 + 70); // HR/GD less technical focus
    }
    
    const keywordMatches = responses.reduce((total, response, index) => {
      const question = questions[index];
      const keywords = question.expectedKeywords || [];
      const matches = keywords.filter(keyword => 
        response.answer.toLowerCase().includes(keyword.toLowerCase())
      ).length;
      return total + (matches / (keywords.length || 1)) * 100;
    }, 0) / responses.length;

    return Math.round(keywordMatches * 0.6 + Math.random() * 40);
  }

  analyzeProblemSolving(responses) {
    const structureScore = responses.reduce((total, response) => {
      const hasStructure = response.answer.includes('first') || 
                          response.answer.includes('step') || 
                          response.answer.includes('approach');
      return total + (hasStructure ? 100 : 50);
    }, 0) / responses.length;

    return Math.round(structureScore * 0.8 + Math.random() * 20);
  }

  analyzeConfidence(responses) {
    const avgConfidence = responses.reduce((sum, r) => sum + r.confidence, 0) / responses.length;
    const timeScore = responses.reduce((total, response) => {
      const efficiency = Math.max(0, 100 - (response.timeSpent / 60) * 10); // Penalty for taking too long
      return total + efficiency;
    }, 0) / responses.length;

    return Math.round((avgConfidence * 0.6 + timeScore * 0.4));
  }

  generateStrengths(scores) {
    const strengths = [];
    if (scores.communication >= 75) strengths.push('Excellent communication skills');
    if (scores.technicalAccuracy >= 75) strengths.push('Strong technical knowledge');
    if (scores.problemSolving >= 75) strengths.push('Structured problem-solving approach');
    if (scores.confidence >= 75) strengths.push('Confident presentation');
    
    if (strengths.length === 0) {
      strengths.push('Shows enthusiasm and willingness to learn');
    }
    
    return strengths;
  }

  generateWeaknesses(scores) {
    const weaknesses = [];
    if (scores.communication < 60) weaknesses.push('Could improve clarity in explanations');
    if (scores.technicalAccuracy < 60) weaknesses.push('Need to strengthen technical knowledge');
    if (scores.problemSolving < 60) weaknesses.push('Could benefit from structured problem-solving');
    if (scores.confidence < 60) weaknesses.push('Could work on building confidence');
    
    return weaknesses.slice(0, 2); // Limit to 2 key areas
  }

  generateSuggestions(scores, type) {
    const suggestions = [];
    
    if (scores.communication < 70) {
      suggestions.push('Practice explaining technical concepts in simple terms');
    }
    if (scores.technicalAccuracy < 70) {
      suggestions.push(`Study core ${type} concepts and practice hands-on problems`);
    }
    if (scores.problemSolving < 70) {
      suggestions.push('Practice breaking down complex problems into smaller steps');
    }
    if (scores.confidence < 70) {
      suggestions.push('Record yourself practicing answers to build confidence');
    }

    suggestions.push('Take more mock interviews to improve overall performance');
    
    return suggestions.slice(0, 3); // Limit to 3 actionable suggestions
  }
}

export const aiService = new MockAIService();