import { GoogleGenerativeAI } from '@google/generative-ai';

class GeminiAIService {
  constructor() {
    // Initialize with environment variable or demo mode
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    if (apiKey) {
      this.genAI = new GoogleGenerativeAI(apiKey);
      this.model = this.genAI.getGenerativeModel({ model: "gemini-2.5-pro" });
    } else {
      this.genAI = null;
      this.model = null;
    }
  }


  async getMotivation(answer) {
  if (!this.model) {
    // Fallback if Gemini is not available
    return { feedback: "💡 Keep going! Small steps lead to big progress." };
  }
  try {
    const prompt = `Read the following interview answer and provide a short, motivational word or phrase to encourage the student. Keep it positive and uplifting.

Answer: ${answer}

Format:
Motivation: [your motivational word or phrase here]`;

    const result = await this.model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    // Extract motivation line
    const motivationLine = text.split('\n').find(line => line.startsWith('Motivation:'));
    return { feedback: motivationLine ? motivationLine.replace('Motivation:', '').trim() : text.trim() };
  } catch (error) {
    console.error("Gemini motivation error:", error);
    return { feedback: "💡 Keep going! Small steps lead to big progress." };
  }
}

  async generateQuestions(
    type,
    domain,
    jobRole,
    jobDescription,
    companyName,
    experience,
    count = 5
  ) {
    if (!this.model) {
      // Fallback to mock questions if no API key
      return this.generateMockQuestions(type, domain, count);
    }

    try {
      const prompt = this.buildQuestionPrompt(type, domain, jobRole, jobDescription, companyName, experience, count);
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      return this.parseQuestionsFromResponse(text, type);
    } catch (error) {
      console.error('Error generating questions with Gemini:', error);
      return this.generateMockQuestions(type, domain, count);
    }
  }

  async generateFeedback(
    responses,
    questions,
    type,
    jobRole,
    jobDescription
  ) {
    if (!this.model) {
      return this.generateMockFeedback(responses, questions, type);
    }

    try {
      const prompt = this.buildFeedbackPrompt(responses, questions, type, jobRole, jobDescription);
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      return this.parseFeedbackFromResponse(text);
    } catch (error) {
      console.error('Error generating feedback with Gemini:', error);
      return this.generateMockFeedback(responses, questions, type);
    }
  }

  buildQuestionPrompt(
    type,
    domain,
    jobRole,
    jobDescription,
    companyName,
    experience,
    count
  ) {
    return `Generate ${count} ${type} interview questions for a ${experience} level ${jobRole} position at ${companyName}.

Job Description: ${jobDescription}
Domain: ${domain}
Interview Type: ${type}

Requirements:
- Questions should be relevant to the job role and company
- Difficulty should match the experience level
- Include a mix of theoretical and practical questions
- For technical interviews, include coding/problem-solving questions
- For HR interviews, focus on behavioral and cultural fit
- For aptitude tests, include logical reasoning and analytical questions
- For group discussions, provide debate topics relevant to the industry

Format each question as:
Q[number]: [Question text]
Difficulty: [easy/medium/hard]
Time: [suggested time in minutes]
Keywords: [comma-separated expected keywords]

Example:
Q1: Explain the difference between REST and GraphQL APIs
Difficulty: medium
Time: 5
Keywords: REST, GraphQL, API, endpoints, queries`;
  }

  buildFeedbackPrompt(
    responses,
    questions,
    type,
    jobRole,
    jobDescription
  ) {
    const qaText = questions.map((q, i) => {
      const response = responses[i];
      return `Q: ${q.text}\nA: ${response?.answer || 'No answer provided'}\nConfidence: ${response?.confidence || 0}%\nTime Spent: ${response?.timeSpent || 0}s`;
    }).join('\n\n');

    return `Analyze this ${type} interview performance for a ${jobRole} position and provide detailed feedback.

Job Role: ${jobRole}
Job Description: ${jobDescription}
Interview Type: ${type}

Questions and Answers:
${qaText}

Please provide feedback in this exact format:

SCORES:
Communication: [0-100]
Technical Accuracy: [0-100]
Problem Solving: [0-100]
Confidence: [0-100]
Overall: [0-100]

STRENGTHS:
- [strength 1]
- [strength 2]
- [strength 3]

WEAKNESSES:
- [weakness 1]
- [weakness 2]

SUGGESTIONS:
- [suggestion 1]
- [suggestion 2]
- [suggestion 3]

Focus on:
- Clarity and structure of answers
- Technical accuracy and depth
- Problem-solving approach
- Communication effectiveness
- Confidence and presentation`;
  }

  parseQuestionsFromResponse(text, type) {
    const questions = [];
    const lines = text.split('\n');
    let currentQuestion = {};

    for (const line of lines) {
      if (line.startsWith('Q') && line.includes(':')) {
        if (currentQuestion.text) {
          questions.push(this.completeQuestion(currentQuestion, type));
        }
        currentQuestion = {
          id: `q_${Date.now()}_${questions.length}`,
          text: line.substring(line.indexOf(':') + 1).trim()
        };
      } else if (line.startsWith('Difficulty:')) {
        currentQuestion.difficulty = line.split(':')[1].trim();
      } else if (line.startsWith('Time:')) {
        const timeStr = line.split(':')[1].trim();
        currentQuestion.timeLimit = parseInt(timeStr) * 60; // Convert to seconds
      } else if (line.startsWith('Keywords:')) {
        currentQuestion.expectedKeywords = line.split(':')[1].split(',').map(k => k.trim());
      }
    }

    if (currentQuestion.text) {
      questions.push(this.completeQuestion(currentQuestion, type));
    }

    return questions.slice(0, 5); // Limit to 5 questions
  }

  completeQuestion(partial, type) {
    return {
      id: partial.id || `q_${Date.now()}_${Math.random()}`,
      text: partial.text || 'Sample question',
      type: this.getQuestionType(type),
      difficulty: partial.difficulty || 'medium',
      timeLimit: partial.timeLimit || 300,
      expectedKeywords: partial.expectedKeywords || []
    };
  }

  parseFeedbackFromResponse(text) {
    const feedback = {
      strengths: [],
      weaknesses: [],
      suggestions: []
    };

    const lines = text.split('\n');
    let currentSection = '';

    for (const line of lines) {
      const trimmed = line.trim();
      
      if (trimmed.startsWith('Communication:')) {
        feedback.communication = parseInt(trimmed.split(':')[1]) || 70;
      } else if (trimmed.startsWith('Technical Accuracy:')) {
        feedback.technicalAccuracy = parseInt(trimmed.split(':')[1]) || 70;
      } else if (trimmed.startsWith('Problem Solving:')) {
        feedback.problemSolving = parseInt(trimmed.split(':')[1]) || 70;
      } else if (trimmed.startsWith('Confidence:')) {
        feedback.confidence = parseInt(trimmed.split(':')[1]) || 70;
      } else if (trimmed.startsWith('Overall:')) {
        feedback.overall = parseInt(trimmed.split(':')[1]) || 70;
      } else if (trimmed === 'STRENGTHS:') {
        currentSection = 'strengths';
      } else if (trimmed === 'WEAKNESSES:') {
        currentSection = 'weaknesses';
      } else if (trimmed === 'SUGGESTIONS:') {
        currentSection = 'suggestions';
      } else if (trimmed.startsWith('- ') && currentSection) {
        const item = trimmed.substring(2);
        if (currentSection === 'strengths') feedback.strengths.push(item);
        else if (currentSection === 'weaknesses') feedback.weaknesses.push(item);
        else if (currentSection === 'suggestions') feedback.suggestions.push(item);
      }
    }

    // Calculate overall if not provided
    if (
      feedback.overall === undefined &&
      feedback.communication !== undefined &&
      feedback.technicalAccuracy !== undefined &&
      feedback.problemSolving !== undefined &&
      feedback.confidence !== undefined
    ) {
      feedback.overall = Math.round(
        (feedback.communication + feedback.technicalAccuracy + feedback.problemSolving + feedback.confidence) / 4
      );
    }

    return {
      overall: feedback.overall || 70,
      communication: feedback.communication || 70,
      technicalAccuracy: feedback.technicalAccuracy || 70,
      problemSolving: feedback.problemSolving || 70,
      confidence: feedback.confidence || 70,
      strengths: feedback.strengths.length ? feedback.strengths : ['Shows enthusiasm for learning'],
      weaknesses: feedback.weaknesses.length ? feedback.weaknesses : ['Could improve response structure'],
      suggestions: feedback.suggestions.length ? feedback.suggestions : ['Practice more mock interviews']
    };
  }

  getQuestionType(interviewType) {
    switch (interviewType) {
      case 'technical': return 'coding';
      case 'aptitude': return 'analytical';
      case 'hr': return 'behavioral';
      case 'group-discussion': return 'behavioral';
      default: return 'text';
    }
  }

  
  generateMockQuestions(type, domain, count) {
    const mockQuestions = {
      aptitude: [
        'What is the next number in the sequence: 2, 6, 12, 20, 30, ?',
        'If all roses are flowers and some flowers fade quickly, what can we conclude?',
        'A train travels 60 km in 40 minutes. What is its speed in km/hr?'
      ],
      hr: [
        'Tell me about yourself and your career aspirations.',
        'Why do you want to work for our company?',
        'Describe a challenging situation you faced and how you handled it.'
      ],
      technical: [
        'Explain the difference between SQL and NoSQL databases.',
        'How would you optimize a slow-performing web application?',
        'Describe your approach to debugging a complex software issue.'
      ],
      'group-discussion': [
        'Should artificial intelligence replace human workers in most industries?',
        'Is remote work more beneficial than office work for productivity?',
        'How important is work-life balance in career success?'
      ]
    };

    const questionPool = mockQuestions[type] || mockQuestions.hr;
    
    return Array.from({ length: count }, (_, index) => ({
      id: `q_${Date.now()}_${index}`,
      text: questionPool[index % questionPool.length],
      type: this.getQuestionType(type),
      difficulty: 'medium',
      timeLimit: 300,
      expectedKeywords: []
    }));
  }

  generateMockFeedback(responses, questions, type) {
    const avgConfidence = responses.reduce((sum, r) => sum + r.confidence, 0) / (responses.length || 1);
    const avgResponseLength = responses.reduce((sum, r) => sum + (r.answer ? r.answer.length : 0), 0) / (responses.length || 1);
    
    const communication = Math.min(100, Math.max(50, avgResponseLength / 10 + Math.random() * 20));
    const technicalAccuracy = Math.min(100, Math.max(40, avgConfidence * 0.8 + Math.random() * 30));
    const problemSolving = Math.min(100, Math.max(45, avgConfidence * 0.9 + Math.random() * 25));
    const confidence = avgConfidence;
    const overall = Math.round((communication + technicalAccuracy + problemSolving + confidence) / 4);

    return {
      overall,
      communication: Math.round(communication),
      technicalAccuracy: Math.round(technicalAccuracy),
      problemSolving: Math.round(problemSolving),
      confidence: Math.round(confidence),
      strengths: ['Clear communication', 'Good technical understanding'],
      weaknesses: ['Could provide more detailed examples'],
      suggestions: ['Practice explaining concepts with real-world examples', 'Work on structuring responses better']
    };
  }
}


export const geminiAIService = new GeminiAIService();