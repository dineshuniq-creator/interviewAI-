// This file was converted from TypeScript types to JavaScript for reference/documentation purposes only.
// You can use these as JSDoc comments or for reference in your JS code.

/**
 * @typedef {'aptitude' | 'group-discussion' | 'hr' | 'technical'} InterviewType
 */

/**
 * @typedef {'software-engineering' | 'data-science' | 'product-management' | 'marketing' | 'finance' | 'sales' | 'operations' | 'design'} Domain
 */

/**
 * @typedef {Object} Question
 * @property {string} id
 * @property {'text' | 'coding' | 'behavioral' | 'analytical'} type
 * @property {'easy' | 'medium' | 'hard'} difficulty
 * @property {number} timeLimit
 * @property {string[]} [expectedKeywords]
 * @property {string} text
 */

/**
 * @typedef {Object} Response
 * @property {string} questionId
 * @property {string} answer
 * @property {number} timeSpent
 * @property {number} confidence
 * @property {Date} timestamp
 */

/**
 * @typedef {Object} Feedback
 * @property {number} overall
 * @property {number} communication
 * @property {number} technicalAccuracy
 * @property {number} problemSolving
 * @property {number} confidence
 * @property {string[]} strengths
 * @property {string[]} weaknesses
 * @property {string[]} suggestions
 */

/**
 * @typedef {Object} InterviewSession
 * @property {string} id
 * @property {string} userId
 * @property {InterviewType} type
 * @property {Domain} domain
 * @property {Question[]} questions
 * @property {Response[]} responses
 * @property {Feedback} [feedback]
 * @property {Date} startTime
 * @property {Date} [endTime]
 * @property {'in-progress' | 'completed' | 'abandoned'} status
 * @property {number} duration
 */

/**
 * @typedef {Object} UserProfile
 * @property {string} id
 * @property {string} name
 * @property {string} email
 * @property {string} jobRole
 * @property {string} jobDescription
 * @property {string} companyName
 * @property {string} [resumeText]
 * @property {'fresher' | 'junior' | 'mid' | 'senior'} experience
 * @property {Domain[]} preferredDomains
 * @property {Date} createdAt
 * @property {number} totalSessions
 * @property {number} averageScore
 */

/**
 * @typedef {Object} PerformanceMetrics
 * @property {number} totalInterviews
 * @property {number} averageScore
 * @property {string} strongestArea
 * @property {string} improvementArea
 * @property {'improving' | 'stable' | 'declining'} progressTrend
 * @property {number[]} recentScores
 */

// No exports needed for JS, these are for documentation/autocomplete only.